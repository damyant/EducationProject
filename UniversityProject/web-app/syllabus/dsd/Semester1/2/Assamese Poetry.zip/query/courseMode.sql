/*
-- Query: SELECT * FROM universityproject_dev.course_mode
LIMIT 0, 1000

-- Date: 2014-04-09 10:29
*/
INSERT INTO `course_mode` (`ModeId`,`version`,`ModeName`) VALUES (1,0,'Semester');
INSERT INTO `course_mode` (`ModeId`,`version`,`ModeName`) VALUES (2,0,'Annual');
