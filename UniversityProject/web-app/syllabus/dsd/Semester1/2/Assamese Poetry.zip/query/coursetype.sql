/*
-- Query: SELECT * FROM universityproject_dev.course_type
LIMIT 0, 1000

-- Date: 2014-04-09 10:29
*/
INSERT INTO `course_type` (`CourseTypeId`,`version`,`courseTypeName`) VALUES (1,0,'Master Degree');
INSERT INTO `course_type` (`CourseTypeId`,`version`,`courseTypeName`) VALUES (2,0,'Post Graduate Diploma');
INSERT INTO `course_type` (`CourseTypeId`,`version`,`courseTypeName`) VALUES (3,0,'Undergraduate');
INSERT INTO `course_type` (`CourseTypeId`,`version`,`courseTypeName`) VALUES (4,0,'Certificate');
