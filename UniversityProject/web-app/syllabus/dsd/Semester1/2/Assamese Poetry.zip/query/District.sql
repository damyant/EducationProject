/*
-- Query: SELECT * FROM universityproject_dev.district
LIMIT 0, 1000

-- Date: 2014-04-09 10:28
*/
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (1,0,'Kamrup Metropolitan',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (2,0,'Jorhat',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (3,0,'Sivasagar',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (4,0,'Cachar',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (5,0,'Nalbari',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (6,0,'Karimganj',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (7,0,'Dima Hasao',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (8,0,'Golaghat',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (9,0,'Lakhimpur',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (10,0,'Dibrugarh',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (11,0,'Kamrup',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (12,0,'Hailakandi',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (13,0,'Dhemaji',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (14,0,'Nagaon',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (15,0,'Bongaigaon',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (16,0,'Tinsukia',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (17,0,'Karbi Anglong',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (18,0,'Baksa',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (19,0,'Morigaon',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (20,0,'Goalpara',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (21,0,'Sonitpur',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (22,0,'Udalguri',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (23,0,'Kokrajhar',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (24,0,'Barpeta',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (25,0,'Chirang',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (26,0,'Darrang',1);
INSERT INTO `district` (`DistrictId`,`version`,`DistrictName`,`StateId`) VALUES (27,0,'Dhubri',1);
