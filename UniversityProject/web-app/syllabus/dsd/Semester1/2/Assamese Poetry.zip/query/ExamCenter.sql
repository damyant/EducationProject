/*
-- Query: SELECT * FROM universityproject_dev.examination_centre
LIMIT 0, 1000

-- Date: 2014-04-09 10:28
*/
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (1,0,'Dibrugarh',1000,1,1,'1111111111','AA','M.D.K. Girls College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (2,1,'Lakhimpur',1000,2,2,'1111111111','AA','North Lakhimpur Law College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (3,1,'Goalpara',1000,3,3,'1111111111','AA','Goalpara College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (4,1,'Tezpur',1000,4,4,'1111111111','AA','Darrang College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (5,1,'Nagaon',1000,5,36,'1111111111','AA','Nowgong College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (6,1,'Kokrajhar',1000,6,5,'1111111111','AA','GU Kokrajhar Campus');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (7,1,'Nalbari',1000,7,6,'1111111111','AA','M.N.C. Balika Mahavidyalay');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (8,1,'Pathsala',1000,8,7,'1111111111','AA','Bajali College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (9,1,'Guwahati',1000,9,8,'1111111111','AA','Gauhati University');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (10,1,'Dhubri',1000,10,9,'1111111111','AA','B. N. College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (11,1,'Bongaigaon',1000,11,10,'1111111111','AA','Birjhora Mahavidyalay');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (12,1,'Jorhat',1000,12,11,'1111111111','AA','C.K.B. Commerce College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (13,1,'Guwahati',1000,13,8,'1111111111','AA','B. Borooah College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (14,1,'Baksa',1000,14,12,'1111111111','AA','Salbari College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (15,1,'Sonitpur',1000,15,13,'1111111111','AA','Biswanath College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (16,1,'Silchar',1000,16,14,'1111111111','AA','G.C. College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (17,1,'Bokakhat',1000,17,15,'1111111111','AA','J.D.S.G. College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (18,1,'Dhemaji',1000,18,16,'1111111111','AA','Simen Chapari College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (19,1,'Mangaldai',1000,19,17,'1111111111','AA','Mangaldoi College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (20,1,'Rangia',1000,20,18,'1111111111','AA','Rangia T.T College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (21,1,'Kalabari',1000,21,19,'1111111111','AA','Kalabari College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (22,1,'Dhekiajuli',1000,22,20,'1111111111','AA','L.O.K.D. College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (23,1,'Nikashi',1000,23,21,'1111111111','AA','Gyanpeeth Degree College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (24,1,'Barpeta',1000,24,22,'1111111111','AA','M.C. College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (25,1,'Chirang',1000,25,23,'1111111111','AA','Bengtol College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (26,1,'Gohpur',1000,26,24,'1111111111','AA','Chaiduar College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (27,1,'Chapar',1000,27,25,'1111111111','AA','Ratnapeeth College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (28,1,'Bilasipara',1000,28,26,'1111111111','AA','Bilasipara College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (29,1,'Jagiroad',1000,29,27,'1111111111','AA','Jagiroad College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (30,1,'Tihu',1000,30,28,'1111111111','AA','Tihu College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (31,1,'Orang',1000,31,29,'1111111111','AA','Kalaguru Bishnu Rabha Degree College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (32,1,'Hojai',1000,32,30,'1111111111','AA','Hojai College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (33,1,'Kharupetia',1000,33,31,'1111111111','AA','Kharupetia College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (34,1,'Dispur',1000,34,32,'1111111111','AA','Dispur College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (35,1,'Bongaigaon',1000,35,10,'1111111111','AA','Bongaigaon College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (36,1,'Howly',1000,36,33,'1111111111','AA','B.H College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (37,1,'Kokrajhar',1000,37,5,'1111111111','AA','Commerce College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (38,1,'Bijni',1000,38,34,'1111111111','AA','Bijni College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (39,1,'Cachar',1000,39,35,'1111111111','AA','Madhab Chandra Das College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (40,2,'Haiborgaon',1000,40,36,'1111111111','AA','A.D.P. College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (41,1,'Kokrajhar',1000,41,5,'1111111111','AA','Bodofa U. N. Brahma College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (42,1,'Tezpur',1000,42,13,'1111111111','AA','Rangapara College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (43,1,'Barpeta',1000,43,22,'1111111111','AA','B.H.B College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (44,1,'Barpeta',1000,44,22,'1111111111','AA','B.B. Kishan College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (45,1,'Udalguri',1000,45,40,'1111111111','AA','Udalguri College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (46,1,'Barpeta',1000,46,22,'1111111111','AA','Nabajyoti College');
INSERT INTO `examination_centre` (`id`,`version`,`Address`,`Capacity`,`CentreCode`,`city_id`,`ContactNo`,`InchargeName`,`Name`) VALUES (47,1,'Barpeta',1000,47,22,'1111111111','AA','N H College');
