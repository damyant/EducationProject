package examinationproject

class Status {

    String status
    static constraints = {
    }
}
