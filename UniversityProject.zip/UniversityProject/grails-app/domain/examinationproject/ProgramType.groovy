package examinationproject

class ProgramType {

    String type

    static constraints = {
    }
}
