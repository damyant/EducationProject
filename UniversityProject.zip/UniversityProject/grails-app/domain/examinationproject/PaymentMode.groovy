package examinationproject

class PaymentMode {

    String paymentModeName

    static constraints = {
    }
}
