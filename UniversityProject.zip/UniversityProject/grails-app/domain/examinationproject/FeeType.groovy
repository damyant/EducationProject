package examinationproject

class FeeType {

    String type

    static constraints = {
    }
}
