package examinationproject

class AdmitCard {

    static constraints = {
    }
}
