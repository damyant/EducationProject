package universityproject

import grails.transaction.Transactional

@Transactional
class AttendanceExcelService {

    def serviceMethod() {

    }
}
